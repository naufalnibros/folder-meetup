<?php

$config = [

    'hostname' => 'localhost',
    'dbname'   => 'crud',
    'username' => 'root',
    'password' => ''

];
